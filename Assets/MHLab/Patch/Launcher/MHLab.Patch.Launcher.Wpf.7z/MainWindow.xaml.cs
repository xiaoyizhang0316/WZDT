﻿using MHLab.Patch.Core.Client;
using MHLab.Patch.Core.Client.IO;
using MHLab.Patch.Core.Client.Progresses;
using MHLab.Patch.Core.Utilities;
using System;
using System.Threading.Tasks;
using System.Threading;
using System.Windows;
using System.Windows.Input;
using MHLab.Patch.Core.IO;
using MHLab.Patch.Launcher.Wpf.Localization;
using MHLab.Patch.Launcher.Wpf.Utilities;

namespace MHLab.Patch.Launcher.Wpf
{
    public partial class MainWindow : Window
    {
        private Repairer _repairer;
        private Updater _updater;
        private PatcherUpdater _patcherUpdater;
        private UpdatingContext _context;

        private Timer _timer;
        private int _elapsed;

        private DateTime _lastTime = DateTime.UtcNow;
        private long _lastSize = 0;
        private int _downloadSpeed = 0;

        private string _launcherExecutableName;
        private string _gameExecutableName;
        private string _gameName;

        public MainWindow()
        {
            InitializeComponent();

            AppDomain.CurrentDomain.UnhandledException += (sender, e) => FatalExceptionObject(e.ExceptionObject);

            Initialize(CreateSettings());

            ResetComponents();
        }

        private LauncherSettings CreateSettings()
        {
            _launcherExecutableName = "MHLab.Patch.Launcher.Wpf.exe";
            _gameName = "YourGame";
            _gameExecutableName = $"{_gameName}.exe";


            var settings = new LauncherSettings
            {
                RemoteUrl = "http://localhost/patch/",
                PatchDownloadAttempts = 3,
                AppDataPath = PathsManager.Combine(PathsManager.GetSpecialPath(Environment.SpecialFolder.ApplicationData), _gameName)
            };

            return settings;
        }

        private void Initialize(LauncherSettings settings)
        {
            var progress = new Progress<UpdateProgress>();
            progress.ProgressChanged += UpdateProgressChanged;

            _context = new UpdatingContext(settings, progress);
            _context.LocalizedMessages = new EnglishUpdaterLocalizedMessages();

            _repairer = new Repairer(_context);
            _repairer.Downloader.DownloadComplete += DownloadComplete;
            _repairer.Downloader.ProgressChanged += DownloadProgressChanged;

            _updater = new Updater(_context);
            _updater.Downloader.DownloadComplete += DownloadComplete;
            _updater.Downloader.ProgressChanged += DownloadProgressChanged;

            _patcherUpdater = new PatcherUpdater(_context);
            _patcherUpdater.Downloader.DownloadComplete += DownloadComplete;
            _patcherUpdater.Downloader.ProgressChanged += DownloadProgressChanged;

            _context.RegisterUpdateStep(_patcherUpdater);
            _context.RegisterUpdateStep(_repairer);
            _context.RegisterUpdateStep(_updater);

            _context.Runner.PerformedStep += (sender, updater) =>
            {
                if (_context.IsDirty) UpdateRestartNeeded();
            };

            VersionLabel.Content = _context.GetLocalVersion();
        }

        private void DownloadProgressChanged(object sender, DownloadEventArgs e)
        {
            if (_lastTime.AddSeconds(1) <= DateTime.UtcNow)
            {
                _downloadSpeed = (int)((e.CurrentFileSize - _lastSize) / (DateTime.UtcNow - _lastTime).TotalSeconds);
                if (_downloadSpeed < 0) _downloadSpeed = 0;
                _lastSize = e.CurrentFileSize;
                _lastTime = DateTime.UtcNow;
            }

            DownloadSpeed.Dispatcher.Invoke(() =>
            {
                DownloadSpeed.Content = FormatUtility.FormatSizeBinary(_downloadSpeed, 2) + "/s"; ;
            });
        }

        private void DownloadComplete(object sender, EventArgs e)
        {
            DownloadSpeed.Dispatcher.Invoke(() =>
            {
                DownloadSpeed.Content = string.Empty;
            });
        }

        private void UpdateProgressChanged(object sender, UpdateProgress e)
        {
            MainProgressBar.Dispatcher.Invoke(() =>
            {
                var totalSteps = Math.Max(e.TotalSteps, 1);

                MainProgressBar.Minimum = 0;
                MainProgressBar.Maximum = totalSteps;
                MainProgressBar.Value = e.CurrentSteps;

                ProgressPercentage.Content = (e.CurrentSteps * 100 / totalSteps) + "%";
            });

            Log(e.StepMessage);
        }

        private void Log(string message)
        {
            MainLog.Dispatcher.Invoke(() =>
            {
                MainLog.Content = message;
            });
        }

        private void ResetComponents()
        {
            MainProgressBar.Dispatcher.Invoke(() => { 
                ProgressPercentage.Content = "";
                DownloadSpeed.Content = "";
                ElapsedTime.Content = "";
                MainLog.Content = "";

                MainProgressBar.Value = 0;
            });
        }

        private void Window_ContentRendered(object sender, EventArgs e)
        {
            try
            {
                _context.Logger.Info("Updating process STARTED!");

                if (!NetworkChecker.IsNetworkAvailable())
                {
                    Log(_context.LocalizedMessages.NotAvailableNetwork);
                    _context.Logger.Error(null, "Updating process FAILED! Network is not available or connectivity is low/weak... Check your connection!");
                    return;
                }

                if (!NetworkChecker.IsRemoteServiceAvailable(_context.Settings.GetRemoteBuildsIndexUrl()))
                {
                    Log(_context.LocalizedMessages.NotAvailableServers);
                    _context.Logger.Error(null, "Updating process FAILED! Our servers are not responding... Wait some minutes and retry!");
                    return;
                }

                _context.Initialize();

                Task.Run(CheckForUpdates);
            }
            catch (Exception ex)
            {
                Log(_context.LocalizedMessages.UpdateProcessFailed);
                _context.Logger.Error(ex, "Updating process FAILED!");
            }
        }

        private void CheckForUpdates()
        {
            UpdateStarted();

            try
            {
                _context.Update();

                UpdateCompleted();
            }
            catch (Exception e)
            {
                UpdateFailed(e);
            }
        }

        private void UpdateStarted()
        {
            _timer = new Timer((state) =>
            {
                _elapsed++;
                ElapsedTime.Dispatcher.Invoke(() =>
                {
                    var minutes = _elapsed / 60;
                    var seconds = _elapsed % 60;

                    ElapsedTime.Content = string.Format("{0}:{1}", (minutes < 10) ? "0" + minutes : minutes.ToString(), (seconds < 10) ? "0" + seconds : seconds.ToString());
                });
            }, null, TimeSpan.Zero, TimeSpan.FromSeconds(1));
        }

        private void UpdateCompleted()
        {
            _timer.Dispose();
            Log(_context.LocalizedMessages.UpdateProcessCompleted);
            _context.Logger.Info("Updating process COMPLETED!");

            VersionLabel.Dispatcher.Invoke(() =>
            {
                VersionLabel.Content = _context.GetLocalVersion();
            });

            MainProgressBar.Dispatcher.Invoke(() =>
            {
                MainProgressBar.Minimum = 0;
                MainProgressBar.Maximum = 1;
                MainProgressBar.Value = 1;

                ProgressPercentage.Content = "100%";
            });

            var launcherPath = PathsManager.Combine(_context.Settings.RootPath, _launcherExecutableName);

            EnsureExecutePrivileges(PathsManager.Combine(_context.Settings.GetGamePath(), _gameExecutableName));
            EnsureExecutePrivileges(launcherPath);

            try
            {
                FilesManager.EnsureShortcutOnDesktop(launcherPath, _launcherExecutableName + " - Shortcut");
            }
            catch (Exception e)
            {
                _context.Logger.Warning("Cannot create desktop shortcut: {0}", e);
            }

            StartGame();
        }

        private void UpdateFailed(Exception e)
        {
            _timer.Dispose();
            ResetComponents();
            Log(_context.LocalizedMessages.UpdateProcessFailed); 
            _context.Logger.Error(e, "Updating process FAILED!");
        }

        private void UpdateRestartNeeded()
        {
            Log(_context.LocalizedMessages.UpdateRestartNeeded);
            _context.Logger.Info("Updating process INCOMPLETE: restart is needed!");
            ApplicationStarter.StartApplication(PathsManager.Combine(_context.Settings.RootPath, _launcherExecutableName), "");
            Environment.Exit(0);
        }

        private void DragMoveMouseDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                if (e.ChangedButton == MouseButton.Left)
                    this.DragMove();
            }
            catch
            {

            }
        }

        void FatalExceptionObject(object exceptionObject)
        {
            Exception exception = exceptionObject as Exception;
            if (exception == null)
            {
                exception = new NotSupportedException(
                    "Unhandled exception doesn't derive from System.Exception: "
                    + exceptionObject.ToString()
                );
            }
            HandleException(exception);
        }

        void HandleException(Exception e)
        {
            _context?.Logger?.Error(e, "Updating process FAILED! An unhandled error occurred!");
        }

        private void EnsureExecutePrivileges(string filePath)
        {
            try
            {
                PrivilegesSetter.EnsureExecutePrivileges(filePath);
            }
            catch (Exception ex)
            {
                _context.Logger.Error(ex, "Unable to set executing privileges on {FilePath}.", filePath);
            }
        }

        private void StartGame()
        {
            var filePath = PathsManager.Combine(_context.Settings.GetGamePath(), _gameExecutableName);
            ApplicationStarter.StartApplication(filePath, $"{_context.Settings.LaunchArgumentParameter}={_context.Settings.LaunchArgumentValue}");
            Environment.Exit(0);
        }
    }
}
