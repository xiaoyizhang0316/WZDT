﻿using System.Diagnostics;

namespace MHLab.Patch.Launcher.Wpf.Utilities
{
    public static class PrivilegesSetter
    {
        public static void EnsureExecutePrivileges(string filePath)
        {
#if MACOS
            EnsurePrivilegesMac(filePath);
#elif LINUX
            EnsurePrivilegesLinux(filePath);
#else
            EnsurePrivilegesWindows(filePath);
#endif
        }

        private static void EnsurePrivilegesWindows(string filePath)
        {

        }

        private static void EnsurePrivilegesMac(string filePath)
        {
            var filename = filePath + "/Contents/MacOS/" + filePath.Replace(".app", "");

            var processChmod = new Process();
            processChmod.StartInfo.FileName = "chmod";
            processChmod.StartInfo.Arguments = "+x \"" + filename + "\"";
            processChmod.Start();

            var processAttr = new Process();
            processAttr.StartInfo.FileName = "xattr";
            processAttr.StartInfo.Arguments = "-d com.apple.quarantine \"" + filePath + "\"";
            processAttr.Start();
        }

        private static void EnsurePrivilegesLinux(string filePath)
        {
            var processChmod = new Process();
            processChmod.StartInfo.FileName = "chmod";
            processChmod.StartInfo.Arguments = "+x \"" + filePath + "\"";
            processChmod.Start();
        }
    }
}
