﻿using System;
using MHLab.Patch.Admin.Localization;
using MHLab.Patch.Core;
using MHLab.Patch.Core.Admin;
using MHLab.Patch.Core.Admin.Localization;
using MHLab.Patch.Core.Admin.Progresses;
using MHLab.Patch.Core.IO;
using Newtonsoft.Json;

namespace MHLab.Patch.Admin
{
    public sealed class AdminCommandLine
    {
        private readonly IAdminLocalizedMessages _localization;
        private readonly AdminSettings _settings;
        private readonly Progress<BuilderProgress> _progress;

        public AdminCommandLine()
        {
            _settings = new AdminSettings();
            _localization = new EnglishAdminLocalizedMessages();

            _progress = new Progress<BuilderProgress>();
            _progress.ProgressChanged += ProgressChanged;
        }

        public void Handle(string[] args)
        {
            switch (args[0])
            {
                case "--init":
                    HandleInitCommand(args);
                    break;
                case "--build":
                    HandleBuildCommand(args);
                    break;
                case "--getVersions":
                    HandleGetVersionsCommand(args);
                    break;
                case "--patch":
                    HandlePatchCommand(args);
                    break;
                case "--patcherUpdate":
                    HandlePatcherUpdateCommand(args);
                    break;
            }
        }

        private void ProgressChanged(object sender, BuilderProgress e)
        {
            Console.WriteLine($"{e.StepMessage} [{e.CurrentSteps}/{e.TotalSteps}]");
        }

        private void HandleInitCommand(string[] args)
        {
            DirectoriesManager.Create(_settings.GetApplicationFolderPath());
            DirectoriesManager.Create(_settings.GetUpdaterFolderPath());
        }

        private void HandleBuildCommand(string[] args)
        {
            var context = new AdminBuildContext(_settings, _progress);

            var lastVersion = context.GetLastVersion();
            Version newVersion;

            if (lastVersion == null) newVersion = new Version(0, 1, 0);
            else
            {
                var releaseType = string.Empty;
                if (args.Length > 1) releaseType = args[1].ToLower();

                newVersion = releaseType switch
                {
                    "major" => new Version(lastVersion.Major + 1, 0, 0),
                    "minor" => new Version(lastVersion.Major, lastVersion.Minor + 1, 0),
                    _ => new Version(lastVersion.Major, lastVersion.Minor, lastVersion.Build + 1)
                };
            }

            context.BuildVersion = newVersion;
            context.LocalizedMessages = _localization;

            context.Initialize();

            var builder = new BuildBuilder(context);
            builder.Build();
        }

        private void HandleGetVersionsCommand(string[] args)
        {
            var context = new AdminPatchContext(_settings, _progress);

            var versions = context.GetVersions();

            Console.WriteLine(JsonConvert.SerializeObject(versions));
        }

        private void HandlePatchCommand(string[] args)
        {
            var context = new AdminPatchContext(_settings, _progress);

            var versions = context.GetVersions();

            if (versions.Count < 2) throw new Exception();

            var last = versions[versions.Count - 1];
            var previous = versions[versions.Count - 2];

            if (args.Length >= 3)
            {
                last = Version.Parse(args[1]);
                previous = Version.Parse(args[2]);
            }

            context.LocalizedMessages = _localization;
            context.VersionFrom = previous;
            context.VersionTo = last;
            context.CompressionLevel = 8;

            context.Initialize();

            var builder = new PatchBuilder(context);
            builder.Build();
        }

        private void HandlePatcherUpdateCommand(string[] args)
        {
            var context = new AdminPatcherUpdateContext(_settings, _progress);
            
            context.LocalizedMessages = _localization;
            
            context.Initialize();

            var builder = new UpdaterBuilder(context);
            builder.Build();
        }
    }
}
